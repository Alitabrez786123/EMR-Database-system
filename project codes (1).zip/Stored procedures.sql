--  Patient Stored Procedures
-- stored procedure create patient
DELIMITER //

CREATE PROCEDURE CreatePatient(
    IN p_name VARCHAR(100),
    IN p_dob DATE,
    IN p_gender VARCHAR(10),
    IN p_contact_details VARCHAR(20),
    IN p_address VARCHAR(255)
)
BEGIN
    INSERT INTO Patient (Name, DOB, Gender, ContactDetails, Address)
    VALUES (p_name, p_dob, p_gender, p_contact_details, p_address);
END //

DELIMITER ;

-- stored procedure Update patient 
DELIMITER //

CREATE PROCEDURE UpdatePatient(
    IN p_patient_id INT,
    IN p_name VARCHAR(100),
    IN p_dob DATE,
    IN p_gender VARCHAR(10),
    IN p_contact_details VARCHAR(20),
    IN p_address VARCHAR(255)
)
BEGIN
    UPDATE Patient
    SET 
        Name = p_name,
        DOB = p_dob,
        Gender = p_gender,
        ContactDetails = p_contact_details,
        Address = p_address
    WHERE PatientID = p_patient_id;
END //

DELIMITER ;

-- Stored procedure delete patient
DELIMITER //

CREATE PROCEDURE DeletePatient(
    IN p_patient_id INT
)
BEGIN
    DELETE FROM Patient
    WHERE PatientID = p_patient_id;
END //

DELIMITER ;

-- Stored procedure View Patient Info
DELIMITER //

CREATE PROCEDURE ViewPatient(
    IN p_patient_id INT
)
BEGIN
    SELECT *
    FROM Patient
    WHERE PatientID = p_patient_id;
END //

DELIMITER ;




-- Appointment Stored Procedures
-- Create Appointment sp
DELIMITER //

CREATE PROCEDURE CreateAppointment(
    IN p_patient_id INT,
    IN p_provider_id INT,
    IN p_date DATE,
    IN p_time TIME,
    IN p_status ENUM('Scheduled','Completed','Cancelled')
)
BEGIN
    INSERT INTO appointment (PatientID, ProviderID, Date, Time, Status)
    VALUES (p_patient_id, p_provider_id, p_date, p_time, p_status);
END //

DELIMITER ;

-- Update Appointment
DELIMITER //

CREATE PROCEDURE UpdateAppointment(
    IN p_appointment_id INT,
    IN p_patient_id INT,
    IN p_provider_id INT,
    IN p_date DATE,
    IN p_time TIME,
    IN p_status ENUM('Scheduled','Completed','Cancelled')
)
BEGIN
    UPDATE appointment
    SET 
        PatientID = p_patient_id,
        ProviderID = p_provider_id,
        Date = p_date,
        Time = p_time,
        Status = p_status
    WHERE AppointmentID = p_appointment_id;
END //

DELIMITER ;


-- Delete Appointment
DELIMITER //

CREATE PROCEDURE DeleteAppointment(
    IN p_appointment_id INT
)
BEGIN
    DELETE FROM appointment
    WHERE AppointmentID = p_appointment_id;
END //

DELIMITER ;


-- View Appointment
DELIMITER //

CREATE PROCEDURE ViewAppointment(
    IN p_appointment_id INT
)
BEGIN
    SELECT *
    FROM appointment
    WHERE AppointmentID = p_appointment_id;
END //

DELIMITER ;




-- Stored procedures for billing

-- Create Billing
DELIMITER //

CREATE PROCEDURE CreateBilling(
    IN p_patient_id INT,
    IN p_visit_id INT,
    IN p_amount DECIMAL(10,2),
    IN p_insurance_claim_status ENUM('Processed','Pending','Rejected','Approved')
)
BEGIN
    INSERT INTO billing (PatientID, VisitID, Amount, InsuranceClaimStatus)
    VALUES (p_patient_id, p_visit_id, p_amount, p_insurance_claim_status);
END //

DELIMITER ;

-- Update Billing
DELIMITER //

CREATE PROCEDURE UpdateBilling(
    IN p_billing_id INT,
    IN p_patient_id INT,
    IN p_visit_id INT,
    IN p_amount DECIMAL(10,2),
    IN p_insurance_claim_status ENUM('Processed','Pending','Rejected','Approved')
)
BEGIN
    UPDATE billing
    SET 
        PatientID = p_patient_id,
        VisitID = p_visit_id,
        Amount = p_amount,
        InsuranceClaimStatus = p_insurance_claim_status
    WHERE BillingID = p_billing_id;
END //

DELIMITER ;

-- Delete Billing
DELIMITER //

CREATE PROCEDURE DeleteBilling(
    IN p_billing_id INT
)
BEGIN
    DELETE FROM billing
    WHERE BillingID = p_billing_id;
END //

DELIMITER ;

-- View Billing
DELIMITER //

CREATE PROCEDURE ViewBilling(
    IN p_billing_id INT
)
BEGIN
    SELECT *
    FROM billing
    WHERE BillingID = p_billing_id;
END //

DELIMITER ;




-- Stored Procedures for clinicalrecord
-- Create Clinical Record
DELIMITER //

CREATE PROCEDURE CreateClinicalRecord(
    IN p_visit_id INT,
    IN p_symptoms TEXT,
    IN p_diagnosis TEXT,
    IN p_prescriptions TEXT,
    IN p_notes TEXT
)
BEGIN
    INSERT INTO clinicalrecord (VisitID, Symptoms, Diagnosis, Prescriptions, Notes)
    VALUES (p_visit_id, p_symptoms, p_diagnosis, p_prescriptions, p_notes);
END //

DELIMITER ;

-- Update Clinical Record
DELIMITER //

CREATE PROCEDURE UpdateClinicalRecord(
    IN p_record_id INT,
    IN p_visit_id INT,
    IN p_symptoms TEXT,
    IN p_diagnosis TEXT,
    IN p_prescriptions TEXT,
    IN p_notes TEXT
)
BEGIN
    UPDATE clinicalrecord
    SET 
        VisitID = p_visit_id,
        Symptoms = p_symptoms,
        Diagnosis = p_diagnosis,
        Prescriptions = p_prescriptions,
        Notes = p_notes
    WHERE RecordID = p_record_id;
END //

DELIMITER ;


-- Delete Clinical Record
DELIMITER //

CREATE PROCEDURE DeleteClinicalRecord(
    IN p_record_id INT
)
BEGIN
    DELETE FROM clinicalrecord
    WHERE RecordID = p_record_id;
END //

DELIMITER ;


-- View Clinical Record
DELIMITER //

CREATE PROCEDURE ViewClinicalRecord(
    IN p_record_id INT
)
BEGIN
    SELECT *
    FROM clinicalrecord
    WHERE RecordID = p_record_id;
END //

DELIMITER ;





-- Stored procedure for prescription
-- Create Prescription
DELIMITER //

CREATE PROCEDURE CreatePrescription(
    IN p_patient_id INT,
    IN p_medication VARCHAR(100),
    IN p_dosage VARCHAR(50),
    IN p_instructions TEXT
)
BEGIN
    INSERT INTO prescription (PatientID, Medication, Dosage, Instructions)
    VALUES (p_patient_id, p_medication, p_dosage, p_instructions);
END //

DELIMITER ;

-- Update Prescription
DELIMITER //

CREATE PROCEDURE UpdatePrescription(
    IN p_prescription_id INT,
    IN p_patient_id INT,
    IN p_medication VARCHAR(100),
    IN p_dosage VARCHAR(50),
    IN p_instructions TEXT
)
BEGIN
    UPDATE prescription
    SET 
        PatientID = p_patient_id,
        Medication = p_medication,
        Dosage = p_dosage,
        Instructions = p_instructions
    WHERE PrescriptionID = p_prescription_id;
END //

DELIMITER ;


-- Delete Prescription
DELIMITER //

CREATE PROCEDURE DeletePrescription(
    IN p_prescription_id INT
)
BEGIN
    DELETE FROM prescription
    WHERE PrescriptionID = p_prescription_id;
END //

DELIMITER ;


-- View Prescription
DELIMITER //

CREATE PROCEDURE ViewPrescription(
    IN p_prescription_id INT
)
BEGIN
    SELECT *
    FROM prescription
    WHERE PrescriptionID = p_prescription_id;
END //

DELIMITER ;




-- Stored procedures test
-- Create Test
DELIMITER //

CREATE PROCEDURE CreateTest(
    IN p_visit_id INT,
    IN p_type VARCHAR(100),
    IN p_results TEXT,
    IN p_date DATE
)
BEGIN
    INSERT INTO test (VisitID, Type, Results, Date)
    VALUES (p_visit_id, p_type, p_results, p_date);
END //

DELIMITER ;


-- Update Test
DELIMITER //

CREATE PROCEDURE UpdateTest(
    IN p_test_id INT,
    IN p_visit_id INT,
    IN p_type VARCHAR(100),
    IN p_results TEXT,
    IN p_date DATE
)
BEGIN
    UPDATE test
    SET 
        VisitID = p_visit_id,
        Type = p_type,
        Results = p_results,
        Date = p_date
    WHERE TestID = p_test_id;
END //

DELIMITER ;


-- Delete Test
DELIMITER //

CREATE PROCEDURE DeleteTest(
    IN p_test_id INT
)
BEGIN
    DELETE FROM test
    WHERE TestID = p_test_id;
END //

DELIMITER ;


-- View Test
DELIMITER //

CREATE PROCEDURE ViewTest(
    IN p_test_id INT
)
BEGIN
    SELECT *
    FROM test
    WHERE TestID = p_test_id;
END //

DELIMITER ;




-- Stored Procedure for visit
-- Create Visit
DELIMITER //

CREATE PROCEDURE CreateVisit(
    IN p_patient_id INT,
    IN p_provider_id INT,
    IN p_date DATE,
    IN p_time TIME,
    IN p_facility VARCHAR(100)
)
BEGIN
    INSERT INTO visit (PatientID, ProviderID, Date, Time, Facility)
    VALUES (p_patient_id, p_provider_id, p_date, p_time, p_facility);
END //

DELIMITER ;


-- Update Visit
DELIMITER //

CREATE PROCEDURE UpdateVisit(
    IN p_visit_id INT,
    IN p_patient_id INT,
    IN p_provider_id INT,
    IN p_date DATE,
    IN p_time TIME,
    IN p_facility VARCHAR(100)
)
BEGIN
    UPDATE visit
    SET 
        PatientID = p_patient_id,
        ProviderID = p_provider_id,
        Date = p_date,
        Time = p_time,
        Facility = p_facility
    WHERE VisitID = p_visit_id;
END //

DELIMITER ;


-- Delete Visit
DELIMITER //

CREATE PROCEDURE DeleteVisit(
    IN p_visit_id INT
)
BEGIN
    DELETE FROM visit
    WHERE VisitID = p_visit_id;
END //

DELIMITER ;


-- View Visit
DELIMITER //

CREATE PROCEDURE ViewVisit(
    IN p_visit_id INT
)
BEGIN
    SELECT *
    FROM visit
    WHERE VisitID = p_visit_id;
END //

DELIMITER ;


-- Stored Procedure provider
-- Create Provider
DELIMITER //

CREATE PROCEDURE CreateProvider(
    IN p_name VARCHAR(100),
    IN p_specialty VARCHAR(100),
    IN p_contact_details VARCHAR(100)
)
BEGIN
    INSERT INTO provider (Name, Specialty, ContactDetails)
    VALUES (p_name, p_specialty, p_contact_details);
END //

DELIMITER ;


-- Update Provider
DELIMITER //

CREATE PROCEDURE UpdateProvider(
    IN p_provider_id INT,
    IN p_name VARCHAR(100),
    IN p_specialty VARCHAR(100),
    IN p_contact_details VARCHAR(100)
)
BEGIN
    UPDATE provider
    SET 
        Name = p_name,
        Specialty = p_specialty,
        ContactDetails = p_contact_details
    WHERE ProviderID = p_provider_id;
END //

DELIMITER ;


-- Delete Provider
DELIMITER //

CREATE PROCEDURE DeleteProvider(
    IN p_provider_id INT
)
BEGIN
    DELETE FROM provider
    WHERE ProviderID = p_provider_id;
END //

DELIMITER ;


-- View Provider
DELIMITER //

CREATE PROCEDURE ViewProvider(
    IN p_provider_id INT
)
BEGIN
    SELECT *
    FROM provider
    WHERE ProviderID = p_provider_id;
END //

DELIMITER ;



DELIMITER //

CREATE PROCEDURE ViewAppointmentByPatient(
    IN p_patient_id INT
)
BEGIN
    SELECT AppointmentID, ProviderID, Date, Time, Status
    FROM Appointment
    WHERE PatientID = p_patient_id;
END //

DELIMITER ;

-- stored procedure for Login Check
DELIMITER //

CREATE PROCEDURE CheckLogin(
    IN p_username VARCHAR(50),
    IN p_password VARCHAR(255),
    IN p_role VARCHAR(50)
)
BEGIN
    SELECT *
    FROM Users
    WHERE Username = p_username
      AND Password = p_password
      AND Role = p_role;
END //

DELIMITER ;


-- View Prescription by patient
DELIMITER //

CREATE PROCEDURE ViewPrescriptionsByPatient(
    IN p_patient_id INT
)
BEGIN
    SELECT PrescriptionID, Medication, Dosage, Instructions
    FROM Prescription
    WHERE PatientID = p_patient_id;
END //

DELIMITER ;


--  Create clinical Record
DELIMITER //

CREATE PROCEDURE CreateClinicalRecord(
    IN p_visit_id INT,
    IN p_symptoms TEXT,
    IN p_diagnosis TEXT,
    IN p_prescriptions TEXT,
    IN p_notes TEXT
)
BEGIN
    IF EXISTS (SELECT 1 FROM Visit WHERE VisitID = p_visit_id) AND 
       NOT EXISTS (SELECT 1 FROM ClinicalRecord WHERE VisitID = p_visit_id) THEN
        INSERT INTO ClinicalRecord (VisitID, Symptoms, Diagnosis, Prescriptions, Notes)
        VALUES (p_visit_id, p_symptoms, p_diagnosis, p_prescriptions, p_notes);
    ELSE
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Invalid Visit ID or Clinical Record already exists for this visit.';
    END IF;
END //

DELIMITER ;


-- view all patients
DELIMITER //

CREATE PROCEDURE ViewAllPatients()
BEGIN
    SELECT PatientID, Name, DOB, Gender, ContactDetails, Address
    FROM Patient;
END //

DELIMITER ;



-- update clinical record
DELIMITER //

CREATE PROCEDURE UpdateClinicalRecord(
    IN p_record_id INT,
    IN p_symptoms TEXT,
    IN p_diagnosis TEXT,
    IN p_prescriptions TEXT,
    IN p_notes TEXT
)
BEGIN
    IF EXISTS (SELECT 1 FROM ClinicalRecord WHERE RecordID = p_record_id) THEN
        UPDATE ClinicalRecord
        SET
            Symptoms = p_symptoms,
            Diagnosis = p_diagnosis,
            Prescriptions = p_prescriptions,
            Notes = p_notes
        WHERE RecordID = p_record_id;
    ELSE
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Clinical Record not found.';
    END IF;
END //

DELIMITER ;



-- ViewAllClinicalRecords
DELIMITER //

CREATE PROCEDURE ViewAllClinicalRecords()
BEGIN
    SELECT 
        cr.RecordID,
        p.PatientID,
        p.Name AS PatientName,
        cr.Symptoms,
        cr.Diagnosis,
        cr.Prescriptions,
        cr.Notes
    FROM ClinicalRecord cr
    JOIN Visit v ON cr.VisitID = v.VisitID
    JOIN Patient p ON v.PatientID = p.PatientID;
END //

DELIMITER ;


-- View billing information
 
DELIMITER //

CREATE PROCEDURE ViewAllBillingInfo()
BEGIN
    SELECT 
        b.BillingID,
        b.PatientID,
        p.Name AS PatientName,
        b.VisitID,
        b.Amount,
        b.InsuranceClaimStatus
    FROM Billing b
    JOIN Patient p ON b.PatientID = p.PatientID;
END //

DELIMITER ;




import mysql.connector

def create_database_connection():
    cnx = mysql.connector.connect(
        host='localhost',
        user='root',              # your mysql username
        password='Localhost!12', # your mysql password
        database='emr'  # your database name
    )
    return cnx

if __name__ == "__main__":
    connection = create_database_connection()
    if connection.is_connected():
        print("Database connection successful!")
        connection.close()
    else:
        print("Failed to connect to the database.")

def authenticate_user(cnx, username, password, role):
    cursor = cnx.cursor()
    cursor.callproc('CheckLogin', [username, password, role])
    for result in cursor.stored_results():
        login_result = result.fetchall()
        if login_result:
            return True
        else:
            return False

def main_menu():
    cnx = create_database_connection()

    if cnx.is_connected():
        print("Database connection successful!")

        username = input("Enter Username: ")
        password = input("Enter Password: ")
        role = input("Enter Role (Patient/Doctor/Receptionist/Staff): ")

        if authenticate_user(cnx, username, password, role):
            print(f"Login successful as {role}!")

            # After successful login, you will show role-based menu here
            if role.lower() == 'patient':
                patient_menu(cnx)
            elif role.lower() == 'doctor':
                doctor_menu(cnx)
            elif role.lower() == 'receptionist':
                receptionist_menu(cnx)
            elif role.lower() == 'staff':
                staff_menu(cnx)
            else:
                print("Invalid role selected.")

        else:
            print("Login failed. Try again.")

        cnx.close()
    else:
        print("Failed to connect to the database.")
        
def patient_menu(cnx):
    while True:
        print("\nPatient Menu:")
        print("1. View My Information")
        print("2. View My Appointments")
        print("3. View My Prescriptions")
        print("4. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            view_patient_info(cnx)
        elif choice == '2':
            view_appointments(cnx)
        elif choice == '3':
            view_prescriptions(cnx)
        elif choice == '4':
            print("Exiting Patient Menu...")
            break
        else:
            print("Invalid choice. Please try again.")


def doctor_menu(cnx):
    while True:
        print("\nDoctor Menu:")
        print("1. View Patient Information")
        print("2. Create Clinical Record")
        print("3. Update Clinical Record")
        print("4. View All Patients")  # NEW OPTION
        print("5. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            view_patient_info(cnx)
        elif choice == '2':
            create_clinical_record(cnx)
        elif choice == '3':
            update_clinical_record(cnx)
        elif choice == '4':
            view_all_patients(cnx)  # CALL FUNCTION
        elif choice == '5':
            print("Exiting Doctor Menu...")
            break
        else:
            print("Invalid choice. Please try again.")



def receptionist_menu(cnx):
    while True:
        print("\nReceptionist Menu:")
        print("1. Create New Patient")
        print("2. Create Appointment")
        print("3. View Appointments")
        print("4. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            create_patient(cnx)
        elif choice == '2':
            create_appointment(cnx)
        elif choice == '3':
            view_appointments(cnx)
        elif choice == '4':
            print("Exiting Receptionist Menu...")
            break
        else:
            print("Invalid choice. Please try again.")


def staff_menu(cnx):
    while True:
        print("\nStaff Menu:")
        print("1. View Patient Information")
        print("2. View Clinical Records")
        print("3. View Billing Information")
        print("4. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            view_patient_info(cnx)
        elif choice == '2':
            view_clinical_records(cnx)
        elif choice == '3':
            view_billing_info(cnx)
        elif choice == '4':
            print("Exiting Staff Menu...")
            break
        else:
            print("Invalid choice. Please try again.")



# For Patient Menu options:
def view_patient_info(cnx):
    patient_id = input("\nEnter your Patient ID: ")

    cursor = cnx.cursor()
    try:
        cursor.callproc('ViewPatient', [patient_id])

        for result in cursor.stored_results():
            rows = result.fetchall()
            if rows:
                for row in rows:
                    print("\nPatient Details:")
                    print(f"ID: {row[0]}")
                    print(f"Name: {row[1]}")
                    print(f"DOB: {row[2]}")
                    print(f"Gender: {row[3]}")
                    print(f"Contact Details: {row[4]}")
                    print(f"Address: {row[5]}")
            else:
                print("\nNo patient found with the given ID.")

    except mysql.connector.Error as error:
        print(f"Failed to fetch patient details: {error}")
    finally:
        cursor.close()


def view_appointments(cnx):
    patient_id = input("\nEnter your Patient ID: ")

    cursor = cnx.cursor()
    try:
        cursor.callproc('ViewAppointmentByPatient', [patient_id])

        for result in cursor.stored_results():
            rows = result.fetchall()
            if rows:
                print("\nYour Appointments:")
                for row in rows:
                    print(f"\nAppointment ID: {row[0]}")
                    print(f"Provider ID: {row[1]}")
                    print(f"Date: {row[2]}")
                    print(f"Time: {row[3]}")
                    print(f"Status: {row[4]}")
            else:
                print("\nNo appointments found for your ID.")

    except mysql.connector.Error as error:
        print(f"Failed to fetch appointments: {error}")
    finally:
        cursor.close()


def view_prescriptions(cnx):
    patient_id = input("\nEnter your Patient ID: ")

    cursor = cnx.cursor()
    try:
        cursor.callproc('ViewPrescriptionsByPatient', [patient_id])

        for result in cursor.stored_results():
            rows = result.fetchall()
            if rows:
                print("\nYour Prescriptions:")
                for row in rows:
                    print(f"\nPrescription ID: {row[0]}")
                    print(f"Medication: {row[1]}")
                    print(f"Dosage: {row[2]}")
                    print(f"Instructions: {row[3]}")
            else:
                print("\nNo prescriptions found for your ID.")

    except mysql.connector.Error as error:
        print(f"Failed to fetch prescriptions: {error}")
    finally:
        cursor.close()


#For Doctor Menu options:
def view_all_patients(cnx):
    print("\n--- All Patients ---")

    cursor = cnx.cursor()
    try:
        cursor.callproc('ViewAllPatients')

        for result in cursor.stored_results():
            rows = result.fetchall()
            if rows:
                for row in rows:
                    print("\nPatient ID:", row[0])
                    print("Name:", row[1])
                    print("DOB:", row[2])
                    print("Gender:", row[3])
                    print("Contact:", row[4])
                    print("Address:", row[5])
            else:
                print("No patients found.")
    except mysql.connector.Error as error:
        print(f"Failed to fetch patients: {error}")
    finally:
        cursor.close()


def create_clinical_record(cnx):
    print("\n--- Create Clinical Record ---")
    visit_id = input("Enter Visit ID: ")
    symptoms = input("Enter Symptoms: ")
    diagnosis = input("Enter Diagnosis: ")
    prescriptions = input("Enter Prescriptions: ")
    notes = input("Enter Additional Notes: ")

    cursor = cnx.cursor()
    try:
        cursor.callproc('CreateClinicalRecord', [visit_id, symptoms, diagnosis, prescriptions, notes])
        cnx.commit()
        print("Clinical record created successfully.")
    except mysql.connector.Error as error:
        print(f"Error while creating clinical record: {error}")
    finally:
        cursor.close()


def update_clinical_record(cnx):
    print("\n--- Update Clinical Record ---")
    record_id = input("Enter Clinical Record ID to update: ")
    symptoms = input("Enter updated Symptoms: ")
    diagnosis = input("Enter updated Diagnosis: ")
    prescriptions = input("Enter updated Prescriptions: ")
    notes = input("Enter updated Notes: ")

    cursor = cnx.cursor()
    try:
        cursor.callproc('UpdateClinicalRecord', [record_id, symptoms, diagnosis, prescriptions, notes])
        cnx.commit()
        print("Clinical record updated successfully.")
    except mysql.connector.Error as error:
        print(f"Error while updating clinical record: {error}")
    finally:
        cursor.close()


# For receptionist menu options:
def create_patient(cnx):
    print("\n--- Create New Patient ---")
    name = input("Enter Name: ")
    dob = input("Enter Date of Birth (YYYY-MM-DD): ")
    gender = input("Enter Gender: ")
    contact = input("Enter Contact Details: ")
    address = input("Enter Address: ")

    cursor = cnx.cursor()
    try:
        cursor.callproc('CreatePatient', [name, dob, gender, contact, address])
        cnx.commit()
        print("Patient record created successfully.")
    except mysql.connector.Error as error:
        print(f"Error creating patient: {error}")
    finally:
        cursor.close()


def create_appointment(cnx):
    print("\n--- Create Appointment ---")
    patient_id = input("Enter Patient ID: ")
    provider_id = input("Enter Provider ID: ")
    date = input("Enter Appointment Date (YYYY-MM-DD): ")
    time = input("Enter Appointment Time (HH:MM:SS): ")
    status = input("Enter Status (Scheduled/Completed/Cancelled): ")

    cursor = cnx.cursor()
    try:
        cursor.callproc('CreateAppointment', [patient_id, provider_id, date, time, status])
        cnx.commit()
        print("Appointment created successfully.")
    except mysql.connector.Error as error:
        print(f"Error creating appointment: {error}")
    finally:
        cursor.close()


# For Staff menu option:
def view_clinical_records(cnx):
    print("\n--- All Clinical Records ---")
    cursor = cnx.cursor()

    try:
        cursor.callproc('ViewAllClinicalRecords')
        for result in cursor.stored_results():
            records = result.fetchall()
            if records:
                for row in records:
                    print(f"\nRecord ID: {row[0]}")
                    print(f"Patient ID: {row[1]}")
                    print(f"Patient Name: {row[2]}")
                    print(f"Symptoms: {row[3]}")
                    print(f"Diagnosis: {row[4]}")
                    print(f"Prescriptions: {row[5]}")
                    print(f"Notes: {row[6]}")
            else:
                print("No clinical records found.")
    except mysql.connector.Error as err:
        print(f"Error: {err}")
    finally:
        cursor.close()


def view_billing_info(cnx):
    print("\n--- Billing Information ---")
    cursor = cnx.cursor()

    try:
        cursor.execute("SELECT * FROM View_Billing_Summary")
        rows = cursor.fetchall()
        if rows:
            for row in rows:
                print(f"\nBilling ID: {row[0]}")
                print(f"Patient Name: {row[1]}")
                print(f"Amount: {row[2]}")
                print(f"Insurance Status: {row[3]}")
        else:
            print("No billing records found.")
    except mysql.connector.Error as error:
        print(f"Error fetching billing info: {error}")
    finally:
        cursor.close()





if __name__ == "__main__":
    main_menu()

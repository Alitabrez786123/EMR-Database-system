
-- Simple Queries --

-- 1. Retrieve the names of patients along with their total number of visits. --
SELECT pat.Name as Name, COUNT(vst.Visit_ID) AS 'Total Number of Visits'
FROM Patient pat
LEFT JOIN Visit vst ON pat.Patient_ID = vst.Patient_ID
GROUP BY pat.Name;

-- 2. Find the average age of all the patients. --
SELECT AVG(YEAR(CURDATE()) - YEAR(Date_of_Birth)) AS 'Average of Age'
FROM Patient;

-- 3. Get the Total Number of appointments scheduled for each provider. --
SELECT prvd.Name as Name, COUNT(vst.Visit_ID) AS 'Total Number of Appointments'
FROM Provider prvd
LEFT JOIN Visit vst ON prvd.Provider_ID = vst.Provider_ID
GROUP BY prvd.Name;

-- 4. List all patient names who has an appoitnment between 1 September 2021 and 31 December 2023 --
SELECT pat.Name as Name, vst.Date_Of_Appointment as 'Date Of Appointment'
FROM Patient pat
JOIN Visit vst ON pat.Patient_ID = vst.Patient_ID 
WHERE vst.Date_Of_Appointment  between '2021-09-30' and '2023-12-31';

-- 5. List all patient names and their insurance Details --
SELECT pat.Name, insr.Insurance_Details as 'Insurance Details'
FROM Patient pat
JOIN insurance insr ON pat.Patient_ID = insr.Patient_ID;

-- 6. Get the total number of patients with insurance. --
SELECT COUNT(*) AS 'Total Number of Patients With Insurance'
FROM Patient pat
left JOIN insurance insr ON pat.Patient_ID = insr.Patient_ID
WHERE Insurance_ID IS NOT NULL;

-- Complex Queries --

-- 7. Get the Names of all the patients got treated in room number 107 each provider --
select pat.Name as Name FROM Patient pat
LEFT JOIN Visit vst ON pat.Patient_ID = vst.Patient_ID
LEFT JOIN clinicalcare clcr ON vst.Visit_ID = clcr.Visit_ID
LEFT JOIN room rmr ON clcr.Room_ID = rmr.Room_ID
where rmr.Room_Number = 107;

-- 8. Patient Billing Analysis: Total Visits, Billing Amount, and Averages --
SELECT 
    pat.Name AS Patient_Name,
    COUNT(DISTINCT vst.Visit_ID) AS 'Total Visits',
    SUM(bill.Amount) AS 'Total Billing Amount',
    AVG(bill.Amount) AS 'Average Billing Amount',
    MAX(bill.Amount) AS 'Maximum Billing Amount'
FROM 
    Patient pat
JOIN 
    Visit vst ON pat.Patient_ID = vst.Patient_ID
JOIN 
    Billing bill ON vst.Visit_ID = bill.Visit_ID
GROUP BY 
    pat.Patient_ID
ORDER BY 
    SUM(bill.Amount) DESC;

-- 9. Showing Name of the Patient, Room Number and Managing Department who were assgined the rooms managed by either Orthopedics or Family Medicine --
SELECT pat.Name as Name, Rm.Room_Number as 'Room Number', Rm.Managing_Department as 'Managing Department'
FROM Patient pat
JOIN Visit vst ON pat.Patient_ID = vst.Patient_ID
JOIN ClinicalCare clcr ON vst.Visit_ID = clcr.Visit_ID
JOIN Room Rm ON clcr.Room_ID = Rm.Room_ID
WHERE Rm.Managing_Department in ('Family Medicine', 'Orthopedics');
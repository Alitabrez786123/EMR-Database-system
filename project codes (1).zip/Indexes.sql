-- Patient Table
CREATE INDEX idx_patient_id ON Patient(PatientID);
CREATE INDEX idx_patient_name ON Patient(Name);

-- Provider Table
CREATE INDEX idx_provider_id ON Provider(ProviderID);
CREATE INDEX idx_provider_name ON Provider(Name);

-- Appointment Table
CREATE INDEX idx_appointment_id ON Appointment(AppointmentID);
CREATE INDEX idx_appointment_patient_id ON Appointment(PatientID);
CREATE INDEX idx_appointment_provider_id ON Appointment(ProviderID);


-- Visit Table
CREATE INDEX idx_visit_id ON Visit(VisitID);
CREATE INDEX idx_visit_patient_id ON Visit(PatientID);
CREATE INDEX idx_visit_provider_id ON Visit(ProviderID);


-- Billing Table
CREATE INDEX idx_billing_id ON Billing(BillingID);
CREATE INDEX idx_billing_patient_id ON Billing(PatientID);
CREATE INDEX idx_billing_visit_id ON Billing(VisitID);


-- ClinicalRecord Table
CREATE INDEX idx_clinicalrecord_id ON ClinicalRecord(RecordID);
CREATE INDEX idx_clinicalrecord_visit_id ON ClinicalRecord(VisitID);


-- Prescription Table
CREATE INDEX idx_prescription_id ON Prescription(PrescriptionID);
CREATE INDEX idx_prescription_patient_id ON Prescription(PatientID);


-- Test Table
CREATE INDEX idx_test_id ON Test(TestID);
CREATE INDEX idx_test_visit_id ON Test(VisitID);

-- View View_Patient_BasicInfo
CREATE VIEW View_Patient_BasicInfo AS
SELECT PatientID, Name, Gender, DOB
FROM Patient;


-- View_Appointment_Details
CREATE VIEW View_Appointment_Details AS
SELECT 
    a.AppointmentID,
    p.Name AS PatientName,
    pr.Name AS ProviderName,
    a.Date,
    a.Time,
    a.Status
FROM Appointment a
JOIN Patient p ON a.PatientID = p.PatientID
JOIN Provider pr ON a.ProviderID = pr.ProviderID;


-- View_Billing_Summary
CREATE VIEW View_Billing_Summary AS
SELECT 
    b.BillingID,
    p.Name AS PatientName,
    b.Amount,
    b.InsuranceClaimStatus
FROM Billing b
JOIN Patient p ON b.PatientID = p.PatientID;


-- View_ClinicalRecord_Summary
CREATE VIEW View_ClinicalRecord_Summary AS
SELECT 
    c.RecordID,
    p.Name AS PatientName,
    v.Date AS VisitDate,
    c.Symptoms,
    c.Diagnosis
FROM ClinicalRecord c
JOIN Visit v ON c.VisitID = v.VisitID
JOIN Patient p ON v.PatientID = p.PatientID;


-- View_Visit_History
CREATE VIEW View_Visit_History AS
SELECT 
    v.VisitID,
    p.Name AS PatientName,
    pr.Name AS ProviderName,
    v.Date,
    v.Time,
    v.Facility
FROM Visit v
JOIN Patient p ON v.PatientID = p.PatientID
JOIN Provider pr ON v.ProviderID = pr.ProviderID;



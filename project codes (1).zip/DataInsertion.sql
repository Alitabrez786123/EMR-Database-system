-- Insert data into Patient table
INSERT INTO Patient (Name, Phone_Number, Emergency_Contact, Address, Gender, Date_of_Birth)
VALUES 
('Sachin Rafic', '987-654-34210', 'Masthan Rafic', '123 Elm Street, Charlotte, NC - 28105', 'Male', '1998-08-25'),
('Arjun Reddy', '798-959-4930', 'Michael Reddy', '456 Oak Avenue, Washington DC, VA - 22209', 'Male', '1990-02-28'),
('Charan Kumar', '875-436-9807', 'Sunil Kumar', '789 Pine Road, Long Beach, CA - 67890', 'Male', '1977-12-31'),
('Pavan Karthik', '765-898-7654', 'Karthik Srinivas', '321 Maple Lane, Anytown, NY - 12345', 'Male', '2004-01-06'),
('Vishal Raju', '945-768-3245', 'Ranjitha Raju', '654 Cedar Street, Anycity, CA - 23454', 'Male', '1955-03-14'),
('Keerthana Kumari', '789-605-4317', 'Chadini Kumari', '987 Birch Boulevard, Cincinnati, OH - 29567', 'Female', '1934-05-01'),
('Sanjana Das', '704-567-9843', 'Liton Das', '258 Cherry Circle, Tampa, FL - 25435', 'Female', '1963-09-29'),
('Keerthi Shetty', '890-123-4567', 'Shyamala Shetty', '369 Dogwood Drive, Tucson, AZ - 25678', 'Female', '2011-04-02');
    
-- Insert data into Insurance table
INSERT INTO Insurance (Patient_ID, Insurance_Details)
VALUES 
(1, 'ISO Health Insurance - Plan 45876'),
(2, 'See - Plan 65093'),
(3, 'UnitedHealth - Plan 33245'),
(4, 'Blue Cross - Plan 99887'),
(5, 'Humana - Plan 44667'),
(6, 'Kaiser Permanente - Plan 99336'),
(7, 'Aetna - Plan 22118'),
(8, 'Blue Shield - Plan 11775');

-- Insert data into Provider table
INSERT INTO Provider (Name, Specialization, Contact)
VALUES 
('Dr. Justin White', 'Oncology', '444-1122'),
('Dr. Taylor Black', 'Orthopedics', '345-0987'),
('Dr. Williams Martin', 'Cardiology', '543-5786'),
('Dr. Srinivas Nayak', 'General Practitioner', '435-2345'),
('Dr. Eric Mely', 'Neurology', '555-5555'),
('Dr. Frank Orange', 'Gastroenterology', '666-7857'),
('Dr. Grace Brown', 'Dermatology', '552-4654'),
('Dr. Vijay Mathew', 'Orthopedics', '344-6576');

-- Insert data into Billing table
INSERT INTO Billing (Visit_ID, Amount, Billing_Date, Payment_Type)
VALUES 
(1, 370.00, '2021-10-01', 'Credit'),
(2, 167.00, '2022-12-31', 'Debit'),
(3, 205.50, '2023-11-06', 'Cash'),
(4, 490.00, '2015-05-26', 'Credit'),
(5, 835.75, '2002-06-30', 'Debit'),
(6, 230.12, '1999-02-23', 'Cash'),
(7, 345.00, '2020-03-01', 'Credit'),
(8, 167.00, '2008-01-04', 'Debit');

-- Insert data into Room table
INSERT INTO Room (Room_Number, Room_Date, Managing_Department, Room_Services)
VALUES 
(101, '2023-11-06', 'Cardiology', 'Heart'),
(102, '2022-12-31', 'Orthopedics', 'Orthopedics'),
(103, '2008-01-04', 'Oncology', 'Cancer Treatment, Chemotherapy'),
(104, '2015-05-26', 'Dermatology', 'Consultation, Skin Care'),
(105, '2023-10-19', 'Neurology', 'Consultation, Brain Imaging'),
(106, '2021-10-01', 'General Practitioner', 'Family Medicine'),
(108, '1999-02-23', 'General Practitioner', 'Family Medicine'),
(107, '2020-03-01', 'Orthopedics', 'Orthopedics');

-- Insert data into Visit table
INSERT INTO Visit (Patient_ID, Provider_ID, Date_Of_Appointment, Time_Of_Appointment, Reason)
VALUES 
(1, 1, '2021-10-01', '10:00:00', 'Routine Checkup'),
(2, 2, '2022-12-31', '11:00:00', 'Knee Pain'),
(3, 3, '2023-11-06', '09:30:00', 'Hearth Checkup'),
(4, 4, '2015-05-26', '14:00:00', 'Skin Rash'),
(7, 2, '2020-03-01', '12:00:00', 'Back Pain'),
(6, 1, '1999-02-23', '10:30:00', 'Follow-up'),
(8, 3, '2008-01-04', '13:00:00', 'Chemotherapy'),
(5, 5, '2002-06-30', '15:30:00', 'Problem related to brain');


-- Insert data into ClinicalCare table
INSERT INTO ClinicalCare (Signs_And_Symptoms, Discharge_Diagnosis, Prescriptions, Tests_And_Procedures, Visit_ID, Room_ID)
VALUES 
('Vitamin Deficiency', 'Lack of vitamins', 'B-Complex', 'Blood Test', 1, 6),
('Knee Pain', 'Arthritis', 'Ibuprofen', 'X-Ray', 2, 2),
('Heart Problem', 'Blockage of Arteries', 'Aspirin', 'CT Scan', 3, 1),
('Skin Rash', 'Eczema', 'Topical Cream', 'Skin Biopsy', 4, 4),
('Back Pain', 'Muscle Strain', 'Physical Therapy', 'MRI', 5, 8),
('Fatigue, Weakness', 'Anemia', 'Iron Supplements', 'Blood Test', 6, 8),
('Cancer Level 3', 'Chemotherapy', 'Dexamethasone', 'Chemotherapy', 7, 3),
('Problem in Brain', 'Alzheimer', 'Aricept', 'Brain Scans and Mental status evaluation', 8, 5);


-- insert into user table
-- Receptionist User
INSERT INTO Users (Username, Password, Role)
VALUES ('reception1', 'password123', 'Receptionist');

-- Doctor User
INSERT INTO Users (Username, Password, Role)
VALUES ('doctor1', 'password123', 'Doctor');

-- Patient User
INSERT INTO Users (Username, Password, Role)
VALUES ('patient1', 'password123', 'Patient');

-- Staff User
INSERT INTO Users (Username, Password, Role)
VALUES ('staff1', 'password123', 'Staff');

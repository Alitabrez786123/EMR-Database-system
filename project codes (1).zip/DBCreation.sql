CREATE database EMR;
USE EMR;

-- Create Patient Table
CREATE TABLE Patient (
    Patient_ID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(100),
    Phone_Number VARCHAR(20),
    Emergency_Contact VARCHAR(100),
    Address VARCHAR(255),
    Gender VARCHAR(10),
    Date_of_Birth DATE
);

-- Create Insurance Table
CREATE TABLE Insurance (
    Insurance_ID INT PRIMARY KEY AUTO_INCREMENT,
    Patient_ID INT,
    Insurance_Details VARCHAR(255),
    FOREIGN KEY (Patient_ID) REFERENCES Patient(Patient_ID)
);

-- Create Provider Table
CREATE TABLE Provider (
    Provider_ID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(100),
    Specialization VARCHAR(100),
    Contact VARCHAR(100),
    Department VARCHAR(100)
);

-- Create Room Table
CREATE TABLE Room (
    Room_ID INT PRIMARY KEY AUTO_INCREMENT,
    Room_Number INT,
    Room_Date DATE,
    Managing_Department VARCHAR(50),
    Room_Services TEXT
);


-- Create Visit Table
CREATE TABLE Visit (
    Visit_ID INT PRIMARY KEY AUTO_INCREMENT,
    Patient_ID INT,
    Provider_ID INT,
    Date_Of_Appointment DATE,
    Time_Of_Appointment TIME,
    Reason TEXT,
    FOREIGN KEY (Patient_ID) REFERENCES Patient(Patient_ID),
    FOREIGN KEY (Provider_ID) REFERENCES Provider(Provider_ID)
);


-- Create ClinicalCare Table
CREATE TABLE ClinicalCare (
    Clinical_ID INT PRIMARY KEY AUTO_INCREMENT,
    Visit_ID INT,
    Room_ID INT,
    Signs_And_Symptoms TEXT,
    Discharge_Diagnosis TEXT,
    Prescriptions TEXT,
    Tests_And_Procedures TEXT,
    FOREIGN KEY (Visit_ID) REFERENCES Visit(Visit_ID),
    FOREIGN KEY (Room_ID) REFERENCES Room(Room_ID)
);

-- Create Billing Table
CREATE TABLE Billing (
    Billing_ID INT PRIMARY KEY AUTO_INCREMENT,
    Visit_ID INT,
    Amount DECIMAL(10, 2),
    Billing_Date DATE,
    Payment_Type VARCHAR(6),  -- ('Debit', 'Credit', 'Cash')
    FOREIGN KEY (Visit_ID) REFERENCES Visit(Visit_ID)
);
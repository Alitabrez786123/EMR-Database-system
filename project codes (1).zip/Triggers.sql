-- Patient Triggers
-- Before Update on Patient
DELIMITER //

CREATE TRIGGER BeforeUpdatePatient
BEFORE UPDATE ON Patient
FOR EACH ROW
BEGIN
    INSERT INTO Audit_Log (TableName, RecordID, OperationType, OldValue, NewValue)
    VALUES (
        'Patient',
        OLD.PatientID,
        'UPDATE',
        CONCAT('Name:', OLD.Name, ', DOB:', OLD.DOB, ', Gender:', OLD.Gender, ', ContactDetails:', OLD.ContactDetails, ', Address:', OLD.Address),
        CONCAT('Name:', NEW.Name, ', DOB:', NEW.DOB, ', Gender:', NEW.Gender, ', ContactDetails:', NEW.ContactDetails, ', Address:', NEW.Address)
    );
END //

DELIMITER ;


-- Before Delete on Patient
DELIMITER //

CREATE TRIGGER BeforeDeletePatient
BEFORE DELETE ON Patient
FOR EACH ROW
BEGIN
    INSERT INTO Audit_Log (TableName, RecordID, OperationType, OldValue, NewValue)
    VALUES (
        'Patient',
        OLD.PatientID,
        'DELETE',
        CONCAT('Name:', OLD.Name, ', DOB:', OLD.DOB, ', Gender:', OLD.Gender, ', ContactDetails:', OLD.ContactDetails, ', Address:', OLD.Address),
        NULL
    );
END //

DELIMITER ;



-- Provider Triggers
-- Before Update on Provider
DELIMITER //

CREATE TRIGGER BeforeUpdateProvider
BEFORE UPDATE ON Provider
FOR EACH ROW
BEGIN
    INSERT INTO Audit_Log (TableName, RecordID, OperationType, OldValue, NewValue)
    VALUES (
        'Provider',
        OLD.ProviderID,
        'UPDATE',
        CONCAT('Name:', OLD.Name, ', Specialty:', OLD.Specialty, ', ContactDetails:', OLD.ContactDetails),
        CONCAT('Name:', NEW.Name, ', Specialty:', NEW.Specialty, ', ContactDetails:', NEW.ContactDetails)
    );
END //

DELIMITER ;


-- Before Delete on Provider
DELIMITER //

CREATE TRIGGER BeforeDeleteProvider
BEFORE DELETE ON Provider
FOR EACH ROW
BEGIN
    INSERT INTO Audit_Log (TableName, RecordID, OperationType, OldValue, NewValue)
    VALUES (
        'Provider',
        OLD.ProviderID,
        'DELETE',
        CONCAT('Name:', OLD.Name, ', Specialty:', OLD.Specialty, ', ContactDetails:', OLD.ContactDetails),
        NULL
    );
END //

DELIMITER ;



-- Visit Triggers
-- Before Update on Visit
DELIMITER //

CREATE TRIGGER BeforeUpdateVisit
BEFORE UPDATE ON Visit
FOR EACH ROW
BEGIN
    INSERT INTO Audit_Log (TableName, RecordID, OperationType, OldValue, NewValue)
    VALUES (
        'Visit',
        OLD.VisitID,
        'UPDATE',
        CONCAT('PatientID:', OLD.PatientID, ', ProviderID:', OLD.ProviderID, ', Date:', OLD.Date, ', Time:', OLD.Time, ', Facility:', OLD.Facility),
        CONCAT('PatientID:', NEW.PatientID, ', ProviderID:', NEW.ProviderID, ', Date:', NEW.Date, ', Time:', NEW.Time, ', Facility:', NEW.Facility)
    );
END //

DELIMITER ;


-- Before Delete on Visit
DELIMITER //

CREATE TRIGGER BeforeDeleteVisit
BEFORE DELETE ON Visit
FOR EACH ROW
BEGIN
    INSERT INTO Audit_Log (TableName, RecordID, OperationType, OldValue, NewValue)
    VALUES (
        'Visit',
        OLD.VisitID,
        'DELETE',
        CONCAT('PatientID:', OLD.PatientID, ', ProviderID:', OLD.ProviderID, ', Date:', OLD.Date, ', Time:', OLD.Time, ', Facility:', OLD.Facility),
        NULL
    );
END //

DELIMITER ;



-- Appointment Triggers
-- Before Update on Appointment
DELIMITER //

CREATE TRIGGER BeforeUpdateAppointment
BEFORE UPDATE ON Appointment
FOR EACH ROW
BEGIN
    INSERT INTO Audit_Log (TableName, RecordID, OperationType, OldValue, NewValue)
    VALUES (
        'Appointment',
        OLD.AppointmentID,
        'UPDATE',
        CONCAT('PatientID:', OLD.PatientID, ', ProviderID:', OLD.ProviderID, ', Date:', OLD.Date, ', Time:', OLD.Time, ', Status:', OLD.Status),
        CONCAT('PatientID:', NEW.PatientID, ', ProviderID:', NEW.ProviderID, ', Date:', NEW.Date, ', Time:', NEW.Time, ', Status:', NEW.Status)
    );
END //

DELIMITER ;


-- Before Delete on Appointment
DELIMITER //

CREATE TRIGGER BeforeDeleteAppointment
BEFORE DELETE ON Appointment
FOR EACH ROW
BEGIN
    INSERT INTO Audit_Log (TableName, RecordID, OperationType, OldValue, NewValue)
    VALUES (
        'Appointment',
        OLD.AppointmentID,
        'DELETE',
        CONCAT('PatientID:', OLD.PatientID, ', ProviderID:', OLD.ProviderID, ', Date:', OLD.Date, ', Time:', OLD.Time, ', Status:', OLD.Status),
        NULL
    );
END //

DELIMITER ;



-- ClinicalRecord Triggers
-- Before Update on ClinicalRecord
DELIMITER //

CREATE TRIGGER BeforeUpdateClinicalRecord
BEFORE UPDATE ON ClinicalRecord
FOR EACH ROW
BEGIN
    INSERT INTO Audit_Log (TableName, RecordID, OperationType, OldValue, NewValue)
    VALUES (
        'ClinicalRecord',
        OLD.RecordID,
        'UPDATE',
        CONCAT('VisitID:', OLD.VisitID, ', Symptoms:', OLD.Symptoms, ', Diagnosis:', OLD.Diagnosis, ', Prescriptions:', OLD.Prescriptions, ', Notes:', OLD.Notes),
        CONCAT('VisitID:', NEW.VisitID, ', Symptoms:', NEW.Symptoms, ', Diagnosis:', NEW.Diagnosis, ', Prescriptions:', NEW.Prescriptions, ', Notes:', NEW.Notes)
    );
END //

DELIMITER ;


-- Before Delete on ClinicalRecord
DELIMITER //

CREATE TRIGGER BeforeDeleteClinicalRecord
BEFORE DELETE ON ClinicalRecord
FOR EACH ROW
BEGIN
    INSERT INTO Audit_Log (TableName, RecordID, OperationType, OldValue, NewValue)
    VALUES (
        'ClinicalRecord',
        OLD.RecordID,
        'DELETE',
        CONCAT('VisitID:', OLD.VisitID, ', Symptoms:', OLD.Symptoms, ', Diagnosis:', OLD.Diagnosis, ', Prescriptions:', OLD.Prescriptions, ', Notes:', OLD.Notes),
        NULL
    );
END //

DELIMITER ;



-- Billing Triggers
-- Before Update on Billing
DELIMITER //

CREATE TRIGGER BeforeUpdateBilling
BEFORE UPDATE ON Billing
FOR EACH ROW
BEGIN
    INSERT INTO Audit_Log (TableName, RecordID, OperationType, OldValue, NewValue)
    VALUES (
        'Billing',
        OLD.BillingID,
        'UPDATE',
        CONCAT('PatientID:', OLD.PatientID, ', VisitID:', OLD.VisitID, ', Amount:', OLD.Amount, ', InsuranceClaimStatus:', OLD.InsuranceClaimStatus),
        CONCAT('PatientID:', NEW.PatientID, ', VisitID:', NEW.VisitID, ', Amount:', NEW.Amount, ', InsuranceClaimStatus:', NEW.InsuranceClaimStatus)
    );
END //

DELIMITER ;


-- Before Delete on Billing
DELIMITER //

CREATE TRIGGER BeforeDeleteBilling
BEFORE DELETE ON Billing
FOR EACH ROW
BEGIN
    INSERT INTO Audit_Log (TableName, RecordID, OperationType, OldValue, NewValue)
    VALUES (
        'Billing',
        OLD.BillingID,
        'DELETE',
        CONCAT('PatientID:', OLD.PatientID, ', VisitID:', OLD.VisitID, ', Amount:', OLD.Amount, ', InsuranceClaimStatus:', OLD.InsuranceClaimStatus),
        NULL
    );
END //

DELIMITER ;





